document.getElementById("end-section").innerHTML = `
<div class="container" style="align-center">
    <div class="row text-white" style="text-align:center; font-size:10px">
        <div class="column">
            <p class="text-white"><Strong>Desain oleh <a href="https://fandiadinata.com" style="text-color:#ffffff; text-decoration:none;">Fandi Adinata</a>. KKN UNS  X  JETIS LOR  @2022</Strong></p>
        </div>
    </div>
</div>
`;